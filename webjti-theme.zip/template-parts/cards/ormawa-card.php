<?php
/**
 * Ormawa Card Template — v2 (archive version)
 *
 * @package WebJTI_Theme
 */

$id      = get_the_ID();
$title   = get_the_title();
$url     = get_permalink();
$excerpt = get_the_excerpt();

// ACF: kategori / tipe ormawa
$kategori = get_field('category') ?: get_field('tipe') ?: '';

$thumbnail_url = has_post_thumbnail()
    ? get_the_post_thumbnail_url($id, 'medium_large')
    : '';
?>

<a href="<?php echo esc_url($url); ?>" class="ormawa-card-v2">

  <div class="ormawa-card-v2__image-wrap">

    <?php if ($thumbnail_url) : ?>
      <img
        src="<?php echo esc_url($thumbnail_url); ?>"
        alt="<?php echo esc_attr($title); ?>"
        class="ormawa-card-v2__logo"
        loading="lazy"
      >
    <?php else : ?>
      <i class="ph ph-users-three ormawa-card-v2__placeholder"></i>
    <?php endif; ?>

    <?php if ($kategori) : ?>
      <span class="ormawa-card-v2__badge"><?php echo esc_html($kategori); ?></span>
    <?php endif; ?>

  </div>

  <div class="ormawa-card-v2__content">

    <h3 class="ormawa-card-v2__title"><?php echo esc_html($title); ?></h3>

    <?php if ($excerpt) : ?>
      <p class="ormawa-card-v2__excerpt"><?php echo wp_trim_words($excerpt, 20); ?></p>
    <?php endif; ?>

    <div class="ormawa-card-v2__footer">
      <span class="ormawa-card-v2__cta">
        Lihat Detail
        <i class="ph ph-arrow-right"></i>
      </span>
    </div>

  </div>

</a>
