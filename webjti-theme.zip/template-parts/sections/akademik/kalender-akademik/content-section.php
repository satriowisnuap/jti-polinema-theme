<?php
/**
 * Akademik Content Section - Kalender Akademik
 *
 * @package WebJTI_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

// Fetch ACF fields
$title          = get_field('kalender_akademik_title');
$description    = get_field('kalender_akademik_description');
$image_data     = get_field('kalender_akademik_image');
$download_text  = get_field('kalender_akademik_download_text');
$download_file  = get_field('kalender_akademik_download_file');
$download_url   = get_field('kalender_akademik_download_url');

// Default fallbacks
if (empty($title)) {
    $title = 'Kalender Akademik';
}

if (empty($download_text)) {
    $download_text = 'Untuk Download Kalender Akademik Tahun Akademik 2025 / 2026';
}

// Process Image URL & Alt
$image_url = '';
$image_alt = 'Kalender Akademik JTI';

if (!empty($image_data)) {
    if (is_array($image_data)) {
        $image_url = $image_data['url'] ?? '';
        $image_alt = !empty($image_data['alt']) ? $image_data['alt'] : $title;
    } elseif (is_numeric($image_data)) {
        $image_src = wp_get_attachment_image_src($image_data, 'full');
        $image_url = $image_src ? $image_src[0] : '';
        $alt_text  = get_post_meta($image_data, '_wp_attachment_image_alt', true);
        if (!empty($alt_text)) {
            $image_alt = $alt_text;
        }
    } elseif (is_string($image_data)) {
        $image_url = $image_data;
    }
}

// Process Download URL
$final_download_url = '';

if (!empty($download_file)) {
    if (is_array($download_file)) {
        $final_download_url = $download_file['url'] ?? '';
    } elseif (is_numeric($download_file)) {
        $final_download_url = wp_get_attachment_url($download_file) ?: '';
    } elseif (is_string($download_file)) {
        $final_download_url = $download_file;
    }
}

if (empty($final_download_url) && !empty($download_url)) {
    $final_download_url = $download_url;
}
?>

<section class="kalender-akademik-section">

    <?php if (!empty($title) || !empty($description)) : ?>
        <div class="kalender-akademik__header">
            <?php if (!empty($title)) : ?>
                <h2 class="kalender-akademik__title">
                    <?php echo esc_html($title); ?>
                </h2>
            <?php endif; ?>

            <?php if (!empty($description)) : ?>
                <div class="kalender-akademik__description">
                    <?php echo wp_kses_post($description); ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Large Display Image Container -->
    <?php if (!empty($image_url)) : ?>
        <div class="kalender-akademik__image-container">
            <div class="kalender-akademik__image-wrapper">
                <a href="<?php echo esc_url($image_url); ?>" target="_blank" title="Lihat Ukuran Penuh">
                    <img
                        src="<?php echo esc_url($image_url); ?>"
                        alt="<?php echo esc_attr($image_alt); ?>"
                        class="kalender-akademik__image"
                        loading="lazy"
                    />
                </a>
            </div>
            <div class="kalender-akademik__image-action">
                <a href="<?php echo esc_url($image_url); ?>" target="_blank" class="kalender-akademik__zoom-btn">
                    <i class="ph ph-magnifying-glass-plus"></i>
                    Buka Ukuran Penuh
                </a>
            </div>
        </div>
    <?php else : ?>
        <!-- Placeholder Box if Image is Not Yet Uploaded in ACF -->
        <div class="kalender-akademik__image-container">
            <div class="kalender-akademik__image-wrapper" style="padding: 60px 20px; text-align: center; color: #79716B;">
                <div style="font-size: 48px; margin-bottom: 12px; color: #EE6D08;">
                    <i class="ph ph-calendar-blank"></i>
                </div>
                <p style="font-size: 16px; font-weight: 500; margin: 0;">
                    Gambar Kalender Akademik belum di-upload. Silakan upload melalui Admin Panel (ACF Fields).
                </p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Download Information Banner -->
    <div class="kalender-akademik__download-box">
        <div class="kalender-akademik__download-info">
            <div class="kalender-akademik__download-icon">
                <i class="ph ph-file-pdf"></i>
            </div>
            <p class="kalender-akademik__download-text">
                <?php echo esc_html($download_text); ?>
            </p>
        </div>

        <?php if (!empty($final_download_url)) : ?>
            <a
                href="<?php echo esc_url($final_download_url); ?>"
                class="kalender-akademik__download-link"
                target="_blank"
                download
            >
                DISINI
                <i class="ph ph-download-simple"></i>
            </a>
        <?php else : ?>
            <a
                href="#"
                class="kalender-akademik__download-link"
                onclick="alert('File download kalender akademik belum tersedia.'); return false;"
            >
                DISINI
                <i class="ph ph-download-simple"></i>
            </a>
        <?php endif; ?>
    </div>

</section>
