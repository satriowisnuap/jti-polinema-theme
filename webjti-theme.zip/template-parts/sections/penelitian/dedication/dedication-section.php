<?php
/**
 * Dedication (Pengabdian Kepada Masyarakat) Section Template
 *
 * @package WebJTI_Theme
 */

$dedications_by_year = webjti_get_dedications();

// Calculate summary stats
$total_projects = 0;
$all_lecturers = [];
$years_list = array_keys($dedications_by_year);

foreach ($dedications_by_year as $year => $projects) {
    $total_projects += count($projects);
    foreach ($projects as $proj) {
        if (!empty($proj['leader'])) {
            $all_lecturers[$proj['leader']] = true;
        }
        if (!empty($proj['members']) && is_array($proj['members'])) {
            foreach ($proj['members'] as $member) {
                $all_lecturers[$member] = true;
            }
        }
    }
}
$total_lecturers = count($all_lecturers);
?>

<section class="dedication-section">
    <!-- Header Block -->
    <div class="dedication-header">
        <div class="dedication-header__content">
            <span class="badge badge--hero-sub">
                <i class="ph ph-globe-hemisphere-east"></i>
                <?php esc_html_e('Tridharma Perguruan Tinggi', 'webjti'); ?>
            </span>
            <h2 class="dedication-header__title">
                <?php esc_html_e('Pengabdian Kepada Masyarakat', 'webjti'); ?>
            </h2>
            <p class="dedication-header__desc">
                <?php esc_html_e('Daftar rekapitulasi kegiatan pengabdian masyarakat yang telah dilaksanakan oleh Dosen Jurusan Teknologi Informasi Politeknik Negeri Malang.', 'webjti'); ?>
            </p>
        </div>

        <!-- Summary Stats Cards -->
        <div class="dedication-stats">
            <div class="dedication-stat-card">
                <div class="dedication-stat-card__icon">
                    <i class="ph ph-folders"></i>
                </div>
                <div class="dedication-stat-card__info">
                    <span class="dedication-stat-card__value"><?php echo esc_html($total_projects); ?></span>
                    <span class="dedication-stat-card__label"><?php esc_html_e('Total Kegiatan', 'webjti'); ?></span>
                </div>
            </div>

            <div class="dedication-stat-card">
                <div class="dedication-stat-card__icon">
                    <i class="ph ph-users-three"></i>
                </div>
                <div class="dedication-stat-card__info">
                    <span class="dedication-stat-card__value"><?php echo esc_html($total_lecturers); ?></span>
                    <span class="dedication-stat-card__label"><?php esc_html_e('Dosen Terlibat', 'webjti'); ?></span>
                </div>
            </div>

            <div class="dedication-stat-card">
                <div class="dedication-stat-card__icon">
                    <i class="ph ph-calendar-blank"></i>
                </div>
                <div class="dedication-stat-card__info">
                    <span class="dedication-stat-card__value"><?php echo esc_html(count($years_list)); ?></span>
                    <span class="dedication-stat-card__label"><?php esc_html_e('Tahun Pelaksanaan', 'webjti'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Toolbar -->
    <div class="dedication-toolbar">
        <div class="dedication-toolbar__years">
            <button type="button" class="dedication-filter-btn active" data-year="all">
                <i class="ph ph-squares-four"></i>
                <?php esc_html_e('Semua Tahun', 'webjti'); ?>
            </button>
            <?php foreach ($years_list as $yr) : ?>
                <button type="button" class="dedication-filter-btn" data-year="<?php echo esc_attr($yr); ?>">
                    <i class="ph ph-calendar"></i>
                    <?php echo esc_html($yr); ?>
                </button>
            <?php endforeach; ?>
        </div>

        <div class="dedication-toolbar__search">
            <i class="ph ph-magnifying-glass"></i>
            <input type="text" id="dedicationSearchInput" placeholder="<?php esc_attr_e('Cari judul, ketua, anggota, atau skema...', 'webjti'); ?>" />
        </div>
    </div>

    <!-- Year Groups Container -->
    <div class="dedication-years-container">
        <?php foreach ($dedications_by_year as $year => $projects) : ?>
            <div class="dedication-year-group" data-year-group="<?php echo esc_attr($year); ?>">
                <div class="dedication-year-group__header">
                    <div class="dedication-year-group__badge">
                        <i class="ph ph-calendar-check"></i>
                        <span>Tahun <?php echo esc_html($year); ?></span>
                    </div>
                    <span class="dedication-year-group__count">
                        <?php printf(esc_html__('%d Kegiatan Pengabdian', 'webjti'), count($projects)); ?>
                    </span>
                </div>

                <div class="dedication-cards-grid">
                    <?php foreach ($projects as $proj_index => $proj) : ?>
                        <div class="dedication-card" data-year="<?php echo esc_attr($year); ?>" data-search-text="<?php echo esc_attr(strtolower($proj['title'] . ' ' . $proj['leader'] . ' ' . implode(' ', $proj['members']) . ' ' . $proj['study_program'] . ' ' . $proj['scheme'])); ?>">
                            <!-- Card Preview / Header -->
                            <div class="dedication-card__header">
                                <div class="dedication-card__tags">
                                    <span class="dedication-card__scheme-tag">
                                        <i class="ph ph-certificate"></i>
                                        <?php echo esc_html($proj['scheme']); ?>
                                    </span>
                                    <span class="dedication-card__prodi-tag">
                                        <i class="ph ph-graduation-cap"></i>
                                        <?php echo esc_html($proj['study_program']); ?>
                                    </span>
                                </div>
                                <h3 class="dedication-card__title">
                                    <?php echo esc_html($proj['title']); ?>
                                </h3>
                                <div class="dedication-card__summary">
                                    <div class="dedication-card__leader-info">
                                        <i class="ph ph-user-circle-gear"></i>
                                        <span><strong>Ketua:</strong> <?php echo esc_html($proj['leader']); ?></span>
                                    </div>
                                    <div class="dedication-card__members-count">
                                        <i class="ph ph-users"></i>
                                        <span><?php echo esc_html(count($proj['members'])); ?> Anggota Tim</span>
                                    </div>
                                </div>
                                <div class="dedication-card__hover-hint">
                                    <i class="ph ph-arrows-out-card"></i>
                                    <span>Detail Kelompok Pengabdian</span>
                                </div>
                            </div>

                            <!-- Detailed Data Grid (Revealed on Hover/Focus - Flexible & No Horizontal Scroll) -->
                            <div class="dedication-card__detail-wrapper">
                                <div class="dedication-detail-badge">
                                    <i class="ph ph-squares-four"></i>
                                    <span>Detail Kelompok Pengabdian</span>
                                </div>

                                <div class="dedication-detail-grid">
                                    <!-- Meta Info: Ketua, Program Studi, & Skema -->
                                    <div class="dedication-detail-row dedication-detail-row--meta">
                                        <div class="detail-item detail-item--leader">
                                            <span class="detail-item__label"><i class="ph ph-user-gear"></i> Nama Ketua</span>
                                            <div class="leader-cell-content">
                                                <div class="leader-avatar">
                                                    <i class="ph ph-user"></i>
                                                </div>
                                                <span class="leader-name"><?php echo esc_html($proj['leader']); ?></span>
                                            </div>
                                        </div>

                                        <div class="detail-item detail-item--prodi">
                                            <span class="detail-item__label"><i class="ph ph-graduation-cap"></i> Program Studi</span>
                                            <span class="badge-prodi"><?php echo esc_html($proj['study_program']); ?></span>
                                        </div>

                                        <div class="detail-item detail-item--scheme">
                                            <span class="detail-item__label"><i class="ph ph-seal-check"></i> Skema</span>
                                            <span class="badge-scheme"><?php echo esc_html($proj['scheme']); ?></span>
                                        </div>
                                    </div>

                                    <!-- Judul Pengabdian -->
                                    <div class="dedication-detail-row">
                                        <div class="detail-item detail-item--full">
                                            <span class="detail-item__label"><i class="ph ph-article"></i> Judul Pengabdian</span>
                                            <span class="dedication-title-text"><?php echo esc_html($proj['title']); ?></span>
                                        </div>
                                    </div>

                                    <!-- Nama Anggota Kelompok -->
                                    <div class="dedication-detail-row">
                                        <div class="detail-item detail-item--full">
                                            <span class="detail-item__label"><i class="ph ph-users"></i> Nama Anggota (<?php echo esc_html(count($proj['members'])); ?> Orang)</span>
                                            <ul class="members-pill-list">
                                                <?php foreach ($proj['members'] as $m_name) : ?>
                                                    <li class="member-pill">
                                                        <i class="ph ph-user-check"></i>
                                                        <span><?php echo esc_html($m_name); ?></span>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Empty Search State -->
    <div id="dedicationEmptyState" class="dedication-empty-state" style="display: none;">
        <i class="ph ph-magnifying-glass"></i>
        <h3>Tidak ada data pengabdian ditemukan</h3>
        <p>Coba kata kunci pencarian lain atau pilih filter tahun berbeda.</p>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterBtns = document.querySelectorAll('.dedication-filter-btn');
    const searchInput = document.getElementById('dedicationSearchInput');
    const cards = document.querySelectorAll('.dedication-card');
    const yearGroups = document.querySelectorAll('.dedication-year-group');
    const emptyState = document.getElementById('dedicationEmptyState');

    function filterDedication() {
        const activeBtn = document.querySelector('.dedication-filter-btn.active');
        const selectedYear = activeBtn ? activeBtn.getAttribute('data-year') : 'all';
        const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : '';

        let visibleCount = 0;

        yearGroups.forEach(group => {
            const groupYear = group.getAttribute('data-year-group');
            const groupCards = group.querySelectorAll('.dedication-card');
            let groupVisibleCards = 0;

            if (selectedYear !== 'all' && selectedYear !== groupYear) {
                group.style.display = 'none';
                return;
            }

            groupCards.forEach(card => {
                const cardText = card.getAttribute('data-search-text') || '';
                const matchesSearch = !searchTerm || cardText.includes(searchTerm);

                if (matchesSearch) {
                    card.style.display = 'block';
                    groupVisibleCards++;
                    visibleCount++;
                } else {
                    card.style.display = 'none';
                }
            });

            if (groupVisibleCards > 0) {
                group.style.display = 'block';
            } else {
                group.style.display = 'none';
            }
        });

        if (emptyState) {
            emptyState.style.display = visibleCount === 0 ? 'block' : 'none';
        }
    }

    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            filterDedication();
        });
    });

    if (searchInput) {
        searchInput.addEventListener('input', filterDedication);
    }
});
</script>
