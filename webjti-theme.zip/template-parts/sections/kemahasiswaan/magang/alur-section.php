<?php
/**
 * Alur Section (Praktik Kerja Lapangan / Magang Timeline)
 * Dynamic tracks for Magang Kolektif & Magang Mandiri + Optional Informative Box
 *
 * @package WebJTI_Theme
 */

$alur_data = webjti_get_magang_alur('all');
$kolektif_items = $alur_data['kolektif'] ?? [];
$mandiri_items  = $alur_data['mandiri'] ?? [];

$page_id = get_the_ID();

// ACF settings for Informative Box (Optional ON/OFF)
$show_info_box_val = function_exists('get_field') ? get_field('magang_info_box_show', $page_id) : get_post_meta($page_id, 'magang_info_box_show', true);
$show_info_box = ($show_info_box_val === '' || $show_info_box_val === null) ? true : (bool)$show_info_box_val;

$info_box_type    = (function_exists('get_field') ? get_field('magang_info_box_type', $page_id) : '') ?: 'info';
$info_box_title   = (function_exists('get_field') ? get_field('magang_info_box_title', $page_id) : '') ?: 'Informasi Penting Perbedaan Magang Kolektif & Magang Mandiri';
$info_box_icon    = (function_exists('get_field') ? get_field('magang_info_box_icon', $page_id) : '') ?: 'ph-info';
$info_box_content = (function_exists('get_field') ? get_field('magang_info_box_content', $page_id) : '');

if (empty($info_box_content)) {
  $info_box_content = '<p><strong>Magang Kolektif:</strong> Dikelola secara terpusat oleh Jurusan TI bekerjasama dengan Perusahaan Mitra resmi. Mahasiswa memilih dan mendaftar lowongan yang telah disediakan di portal.</p><p><strong>Magang Mandiri:</strong> Mahasiswa mengajukan calon perusahaan/instansi secara mandiri di luar daftar mitra resmi, dengan verifikasi persetujuan kelayakan dari tim magang jurusan.</p>';
}

ob_start();
?>

<div class="alur-section timeline-section tabs-container alur-tabs-container">

  <!-- Dynamic Tabs Navigation Header -->
  <div class="alur-tabs-header" role="tablist" aria-label="Jenis Magang">
    <button
      type="button"
      class="tab-btn alur-tab-btn active"
      role="tab"
      id="tab-magang-kolektif"
      aria-controls="panel-magang-kolektif"
      aria-selected="true"
    >
      <i class="ph-bold ph-users-three" aria-hidden="true"></i>
      <span>Magang Kolektif</span>
      <span class="alur-tab-badge">Mitra JTI</span>
    </button>

    <button
      type="button"
      class="tab-btn alur-tab-btn"
      role="tab"
      id="tab-magang-mandiri"
      aria-controls="panel-magang-mandiri"
      aria-selected="false"
    >
      <i class="ph-bold ph-user-gear" aria-hidden="true"></i>
      <span>Magang Mandiri</span>
      <span class="alur-tab-badge">Pengajuan Mandiri</span>
    </button>
  </div>

  <!-- Tab Panel 1: Magang Kolektif -->
  <div
    class="tab-panel alur-tab-panel active"
    id="panel-magang-kolektif"
    role="tabpanel"
    aria-labelledby="tab-magang-kolektif"
  >
    <?php if (!empty($kolektif_items)) : ?>
      <div class="alur-section__container alur-container timeline-container">
        <?php foreach ($kolektif_items as $index => $item) : ?>
          <?php
          get_template_part(
            'template-parts/sections/kemahasiswaan/magang/alur-item',
            null,
            [
              'item'  => $item,
              'index' => $index + 1,
            ]
          );
          ?>
        <?php endforeach; ?>
      </div>
    <?php else : ?>
      <p class="alur-section__empty timeline-section__empty">
        <?php esc_html_e('Belum ada data alur magang kolektif.', 'webjti'); ?>
      </p>
    <?php endif; ?>
  </div>

  <!-- Tab Panel 2: Magang Mandiri -->
  <div
    class="tab-panel alur-tab-panel"
    id="panel-magang-mandiri"
    role="tabpanel"
    aria-labelledby="tab-magang-mandiri"
  >
    <?php if (!empty($mandiri_items)) : ?>
      <div class="alur-section__container alur-container timeline-container">
        <?php foreach ($mandiri_items as $index => $item) : ?>
          <?php
          get_template_part(
            'template-parts/sections/kemahasiswaan/magang/alur-item',
            null,
            [
              'item'  => $item,
              'index' => $index + 1,
            ]
          );
          ?>
        <?php endforeach; ?>
      </div>
    <?php else : ?>
      <p class="alur-section__empty timeline-section__empty">
        <?php esc_html_e('Belum ada data alur magang mandiri.', 'webjti'); ?>
      </p>
    <?php endif; ?>
  </div>

  <!-- Optional Informative Box -->
  <?php if ($show_info_box) : ?>
    <div class="alur-info-box alur-info-box--<?php echo esc_attr($info_box_type); ?>">
      <div class="alur-info-box__icon">
        <i class="ph-fill <?php echo esc_attr($info_box_icon); ?>" aria-hidden="true"></i>
      </div>
      <div class="alur-info-box__content">
        <?php if (!empty($info_box_title)) : ?>
          <h4 class="alur-info-box__title"><?php echo esc_html($info_box_title); ?></h4>
        <?php endif; ?>
        <div class="alur-info-box__text">
          <?php echo wp_kses_post($info_box_content); ?>
        </div>
      </div>
    </div>
  <?php endif; ?>

</div>

<?php
$content = ob_get_clean();

get_template_part(
  'template-parts/components/content-block',
  null,
  [
    'title' => 'Alur pengajuan magang mahasiswa:',
    'icon' => 'ph-steps',
    'content' => $content,
    'section_slug' => 'alur-magang',
    'allow_custom_title' => true,
    'allow_custom_icon' => true,
  ]
);

