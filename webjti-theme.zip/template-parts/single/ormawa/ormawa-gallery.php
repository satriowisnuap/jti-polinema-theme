<?php
/**
 * Ormawa Gallery Section Template
 *
 * @package WebJTI_Theme
 */

$galeri = $args['galeri'] ?? [];

if (empty($galeri)) {
    return;
}

$total_images = count($galeri);
?>

<div class="ormawa-gallery slider-wrapper" data-total="<?php echo (int) $total_images; ?>">

    <div class="ormawa-gallery__topbar">
        <h3 class="ormawa-gallery__heading">Galeri Kegiatan</h3>
    </div>

    <div class="slider-container ormawa-gallery__slider-container">
        <div class="slider-track ormawa-gallery__track" data-total="<?php echo (int) $total_images; ?>">

            <?php foreach ($galeri as $image) :

                // Support both ACF array format and attachment ID format
                if (is_numeric($image)) {
                    $src         = wp_get_attachment_image_url((int) $image, 'large') ?: wp_get_attachment_url((int) $image);
                    $alt         = get_post_meta((int) $image, '_wp_attachment_image_alt', true) ?: get_the_title((int) $image);
                    $img_title   = get_the_title((int) $image);
                    $img_caption = wp_get_attachment_caption((int) $image);
                } else {
                    $src         = $image['sizes']['large'] ?? $image['url'] ?? '';
                    $alt         = $image['alt'] ?? $image['title'] ?? '';
                    $img_title   = $image['title'] ?? '';
                    $img_caption = $image['caption'] ?? '';
                }

                // Skip items with no image URL
                if (empty($src)) continue;
            ?>
                <div class="slider-item ormawa-gallery__item">
                    <div class="ormawa-gallery__image-wrap">
                        <img
                            src="<?php echo esc_url($src); ?>"
                            alt="<?php echo esc_attr($alt); ?>"
                            class="ormawa-gallery__img"
                            loading="lazy"
                        >
                        <?php if ($img_caption) : ?>
                            <div class="ormawa-gallery__overlay">
                                <div class="ormawa-gallery__caption">
                                    <p><?php echo esc_html($img_caption); ?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($img_title) : ?>
                        <div class="ormawa-gallery__title-wrap">
                            <span class="ormawa-gallery__title"><?php echo esc_html($img_title); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>

        </div>
    </div>

</div>
