<?php

/* ========================================
   SAFE ACF FIELD
======================================== */

function webjti_field(
  $field_name,
  $post_id = false,
  $default = ''
) {

  if (!function_exists('get_field')) {
    return $default;
  }

  $value =
    get_field(
      $field_name,
      $post_id
    );

    return $value ?: $default;

}

/* ========================================
   REGISTER ORMAWA ACF FIELDS PROGRAMMATICALLY
======================================== */

add_action('acf/init', 'webjti_register_ormawa_fields');
function webjti_register_ormawa_fields() {
    if (function_exists('acf_add_local_field_group')) {
        acf_add_local_field_group(array(
            'key' => 'group_ormawa_details',
            'title' => 'Organisasi Details',
            'fields' => array(
                array(
                    'key' => 'field_ormawa_history',
                    'label' => 'History',
                    'name' => 'history',
                    'type' => 'wysiwyg',
                    'instructions' => 'Sejarah singkat organisasi',
                    'required' => 0,
                    'media_upload' => 0,
                    'toolbar' => 'full',
                ),
                array(
                    'key' => 'field_ormawa_vision',
                    'label' => 'Vision',
                    'name' => 'vision',
                    'type' => 'wysiwyg',
                    'instructions' => 'Visi organisasi',
                    'required' => 0,
                    'media_upload' => 0,
                    'toolbar' => 'basic',
                ),
                array(
                    'key' => 'field_ormawa_mission',
                    'label' => 'Mission',
                    'name' => 'mission',
                    'type' => 'wysiwyg',
                    'instructions' => 'Misi organisasi',
                    'required' => 0,
                    'media_upload' => 0,
                    'toolbar' => 'basic',
                ),
                array(
                    'key' => 'field_ormawa_objective',
                    'label' => 'Objective',
                    'name' => 'objective',
                    'type' => 'wysiwyg',
                    'instructions' => 'Tujuan organisasi',
                    'required' => 0,
                    'media_upload' => 0,
                    'toolbar' => 'basic',
                ),
                array(
                    'key' => 'field_ormawa_program',
                    'label' => 'Program',
                    'name' => 'program',
                    'type' => 'wysiwyg',
                    'instructions' => 'Program kerja unggulan',
                    'required' => 0,
                    'media_upload' => 0,
                    'toolbar' => 'full',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'ormawa',
                    ),
                ),
            ),
            'menu_order' => 0,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'hide_on_screen' => '',
            'active' => true,
            'description' => 'Metabox untuk detail Organisasi Kemahasiswaan',
            'show_in_rest' => 1,
        ));

        acf_add_local_field_group(array(
            'key' => 'group_ormawa_gallery_details',
            'title' => 'Gallery Kegiatan Details',
            'fields' => array(
                array(
                    'key' => 'field_gallery_associated_ormawa',
                    'label' => 'Organisasi',
                    'name' => 'associated_ormawa',
                    'type' => 'post_object',
                    'instructions' => 'Pilih organisasi kemahasiswaan yang terkait',
                    'required' => 1,
                    'post_type' => array(
                        0 => 'ormawa',
                    ),
                    'taxonomy' => '',
                    'allow_null' => 0,
                    'multiple' => 0,
                    'return_format' => 'id',
                    'ui' => 1,
                ),
                array(
                    'key' => 'field_gallery_photo',
                    'label' => 'Foto Kegiatan',
                    'name' => 'gallery_photo',
                    'type' => 'image',
                    'instructions' => 'Upload foto kegiatan organisasi',
                    'required' => 1,
                    'return_format' => 'array',
                    'preview_size' => 'medium',
                    'library' => 'all',
                ),
                array(
                    'key' => 'field_gallery_description',
                    'label' => 'Deskripsi',
                    'name' => 'description',
                    'type' => 'textarea',
                    'instructions' => 'Deskripsi singkat mengenai foto kegiatan ini',
                    'required' => 0,
                    'rows' => 3,
                    'new_lines' => 'br',
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'ormawa_gallery',
                    ),
                ),
            ),
            'menu_order' => 0,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'hide_on_screen' => '',
            'active' => true,
            'description' => 'Metabox untuk detail foto kegiatan organisasi',
            'show_in_rest' => 1,
        ));
    }
}

/* ========================================
   REGISTER ACF FIELD GROUPS (TATA TERTIB)
======================================== */
add_action('acf/init', function() {
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }

    acf_add_local_field_group([
        'key' => 'group_6a1200tata_tertib',
        'title' => 'Content Block Tata Tertib',
        'fields' => [
            [
                'key' => 'field_6a1200_tt_title',
                'label' => 'Tata Tertib Header Title',
                'name' => 'tata_tertib_title',
                'type' => 'text',
                'default_value' => 'Tata Tertib Kehidupan Kampus',
            ],
            [
                'key' => 'field_6a1200_tt_desc',
                'label' => 'Tata Tertib Header Description',
                'name' => 'tata_tertib_description',
                'type' => 'textarea',
                'default_value' => 'Tata tertib kehidupan kampus di Polinema disusun untuk menjaga ketertiban dan kedisiplinan di lingkungan kampus.',
            ],
            [
                'key' => 'field_6a1200_hak_title',
                'label' => 'Hak Mahasiswa Title',
                'name' => 'hak_title',
                'type' => 'text',
                'default_value' => 'Hak Mahasiswa',
            ],
            [
                'key' => 'field_6a1200_hak_icon',
                'label' => 'Hak Mahasiswa Icon',
                'name' => 'hak_icon',
                'type' => 'text',
                'default_value' => 'ph-user-check',
            ],
            [
                'key' => 'field_6a1200_hak_list',
                'label' => 'Hak Mahasiswa List',
                'name' => 'hak_list',
                'type' => 'repeater',
                'layout' => 'table',
                'button_label' => 'Tambah Hak Mahasiswa',
                'sub_fields' => [
                    [
                        'key' => 'field_6a1200_hak_item_text',
                        'label' => 'Poin Hak',
                        'name' => 'item',
                        'type' => 'textarea',
                    ]
                ]
            ],
            [
                'key' => 'field_6a1200_hak_content',
                'label' => 'Hak Mahasiswa Content (WYSIWYG)',
                'name' => 'hak_content',
                'type' => 'wysiwyg',
            ],
            [
                'key' => 'field_6a1200_kewajiban_title',
                'label' => 'Kewajiban Mahasiswa Title',
                'name' => 'kewajiban_title',
                'type' => 'text',
                'default_value' => 'Kewajiban Mahasiswa',
            ],
            [
                'key' => 'field_6a1200_kewajiban_icon',
                'label' => 'Kewajiban Mahasiswa Icon',
                'name' => 'kewajiban_icon',
                'type' => 'text',
                'default_value' => 'ph-clipboard-text',
            ],
            [
                'key' => 'field_6a1200_kewajiban_list',
                'label' => 'Kewajiban Mahasiswa List',
                'name' => 'kewajiban_list',
                'type' => 'repeater',
                'layout' => 'table',
                'button_label' => 'Tambah Kewajiban',
                'sub_fields' => [
                    [
                        'key' => 'field_6a1200_kewajiban_item_text',
                        'label' => 'Poin Kewajiban',
                        'name' => 'item',
                        'type' => 'textarea',
                    ]
                ]
            ],
            [
                'key' => 'field_6a1200_kewajiban_content',
                'label' => 'Kewajiban Mahasiswa Content (WYSIWYG)',
                'name' => 'kewajiban_content',
                'type' => 'wysiwyg',
            ],
            [
                'key' => 'field_6a1200_larangan_title',
                'label' => 'Larangan Title',
                'name' => 'larangan_title',
                'type' => 'text',
                'default_value' => 'Larangan bagi Mahasiswa',
            ],
            [
                'key' => 'field_6a1200_larangan_icon',
                'label' => 'Larangan Icon',
                'name' => 'larangan_icon',
                'type' => 'text',
                'default_value' => 'ph-warning-octagon',
            ],
            [
                'key' => 'field_6a1200_larangan_list',
                'label' => 'Larangan List',
                'name' => 'larangan_list',
                'type' => 'repeater',
                'layout' => 'table',
                'button_label' => 'Tambah Larangan',
                'sub_fields' => [
                    [
                        'key' => 'field_6a1200_larangan_item_text',
                        'label' => 'Poin Larangan',
                        'name' => 'item',
                        'type' => 'textarea',
                    ]
                ]
            ],
            [
                'key' => 'field_6a1200_larangan_content',
                'label' => 'Larangan Content (WYSIWYG)',
                'name' => 'larangan_content',
                'type' => 'wysiwyg',
            ],
            [
                'key' => 'field_6a1200_klasifikasi_title',
                'label' => 'Klasifikasi Section Title',
                'name' => 'klasifikasi_title',
                'type' => 'text',
                'default_value' => 'Klasifikasi dan Tingkat Pelanggaran',
            ],
            [
                'key' => 'field_6a1200_klasifikasi_icon',
                'label' => 'Klasifikasi Icon',
                'name' => 'klasifikasi_icon',
                'type' => 'text',
                'default_value' => 'ph-list-checks',
            ],
            [
                'key' => 'field_6a1200_klasifikasi_desc',
                'label' => 'Klasifikasi Description',
                'name' => 'klasifikasi_description',
                'type' => 'textarea',
                'default_value' => 'Pelanggaran terhadap tata tertib di atas dikategori menjadi 5 tingkat pelanggaran:',
            ],
            [
                'key' => 'field_6a1200_tingkat_list',
                'label' => 'Tingkat Pelanggaran List',
                'name' => 'tingkat_pelanggaran_list',
                'type' => 'repeater',
                'layout' => 'table',
                'button_label' => 'Tambah Tingkat Pelanggaran',
                'sub_fields' => [
                    [
                        'key' => 'field_6a1200_tingkat_nama',
                        'label' => 'Tingkat Pelanggaran',
                        'name' => 'tingkat',
                        'type' => 'text',
                    ],
                    [
                        'key' => 'field_6a1200_tingkat_kategori',
                        'label' => 'Kategori',
                        'name' => 'kategori',
                        'type' => 'text',
                    ]
                ]
            ],
            [
                'key' => 'field_6a1200_akumulasi_title',
                'label' => 'Akumulasi Title',
                'name' => 'akumulasi_title',
                'type' => 'text',
                'default_value' => 'Aturan Akumulasi Pelanggaran',
            ],
            [
                'key' => 'field_6a1200_akumulasi_desc',
                'label' => 'Akumulasi Description',
                'name' => 'akumulasi_description',
                'type' => 'textarea',
                'default_value' => 'Pelanggaran Tata Tertib Kehidupan Kampus akan diakumulasikan untuk setiap kategori pelanggaran dan berlaku sepanjang mahasiswa masih tercatat sebagai mahasiswa di Polinema. Akumulasi Pelanggaran Tata Tertib Kehidupan kampus mengikuti aturan sebagai berikut:',
            ],
            [
                'key' => 'field_6a1200_akumulasi_list',
                'label' => 'Akumulasi List',
                'name' => 'akumulasi_list',
                'type' => 'repeater',
                'layout' => 'table',
                'button_label' => 'Tambah Aturan Akumulasi',
                'sub_fields' => [
                    [
                        'key' => 'field_6a1200_akumulasi_rule_text',
                        'label' => 'Aturan Akumulasi',
                        'name' => 'rule',
                        'type' => 'textarea',
                    ]
                ]
            ],
            [
                'key' => 'field_6a1200_sanksi_title',
                'label' => 'Sanksi Title',
                'name' => 'sanksi_title',
                'type' => 'text',
                'default_value' => 'Sanksi Pelanggaran',
            ],
            [
                'key' => 'field_6a1200_sanksi_icon',
                'label' => 'Sanksi Icon',
                'name' => 'sanksi_icon',
                'type' => 'text',
                'default_value' => 'ph-shield-warning',
            ],
            [
                'key' => 'field_6a1200_sanksi_list',
                'label' => 'Sanksi List',
                'name' => 'sanksi_list',
                'type' => 'repeater',
                'layout' => 'block',
                'button_label' => 'Tambah Sanksi',
                'sub_fields' => [
                    [
                        'key' => 'field_6a1200_sanksi_tingkat',
                        'label' => 'Tingkat Sanksi',
                        'name' => 'tingkat',
                        'type' => 'text',
                    ],
                    [
                        'key' => 'field_6a1200_sanksi_detail',
                        'label' => 'Detail Sanksi',
                        'name' => 'detail',
                        'type' => 'wysiwyg',
                    ]
                ]
            ],
            [
                'key' => 'field_6a1200_sanksi_content',
                'label' => 'Sanksi Content (WYSIWYG)',
                'name' => 'sanksi_content',
                'type' => 'wysiwyg',
            ]
        ],
        'location' => [
            [
                [
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'templates/pages/tata-tertib-page.php',
                ],
            ],
        ],
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (KALENDER AKADEMIK)
    ======================================== */
    acf_add_local_field_group([
        'key' => 'group_kalender_akademik_page',
        'title' => 'Content Kalender Akademik',
        'fields' => [
            [
                'key' => 'field_kalender_akademik_title',
                'label' => 'Judul Kalender Akademik',
                'name' => 'kalender_akademik_title',
                'type' => 'text',
                'instructions' => 'Judul utama pada halaman kalender akademik',
                'default_value' => 'Kalender Akademik',
            ],
            [
                'key' => 'field_kalender_akademik_description',
                'label' => 'Deskripsi Kalender Akademik',
                'name' => 'kalender_akademik_description',
                'type' => 'wysiwyg',
                'instructions' => 'Deskripsi atau catatan seputar Kalender Akademik',
                'default_value' => 'Berikut adalah Kalender Akademik Jurusan Teknologi Informasi Polinema.',
                'media_upload' => 0,
                'toolbar' => 'full',
                'tabs' => 'visual',
            ],
            [
                'key' => 'field_kalender_akademik_image',
                'label' => 'Gambar Kalender Akademik',
                'name' => 'kalender_akademik_image',
                'type' => 'image',
                'instructions' => 'Upload atau pilih gambar Kalender Akademik (akan ditampilkan secara besar)',
                'return_format' => 'array',
                'preview_size' => 'large',
                'library' => 'all',
            ],
            [
                'key' => 'field_kalender_akademik_download_text',
                'label' => 'Teks Keterangan Download',
                'name' => 'kalender_akademik_download_text',
                'type' => 'text',
                'instructions' => 'Contoh: Untuk Download Kalender Akademik Tahun Akademik 2025 / 2026',
                'default_value' => 'Untuk Download Kalender Akademik Tahun Akademik 2025 / 2026',
            ],
            [
                'key' => 'field_kalender_akademik_download_file',
                'label' => 'File Download Kalender Akademik',
                'name' => 'kalender_akademik_download_file',
                'type' => 'file',
                'instructions' => 'Upload file dokumen (PDF/Gambar/Zip) yang dapat di-download',
                'return_format' => 'array',
                'library' => 'all',
            ],
            [
                'key' => 'field_kalender_akademik_download_url',
                'label' => 'Link Download Eksternal (Opsional)',
                'name' => 'kalender_akademik_download_url',
                'type' => 'url',
                'instructions' => 'Link alternatif jika file di-host di luar WordPress (misal: Google Drive)',
            ],
        ],
        'location' => [
            [
                [
                    'param' => 'page_template',
                    'operator' => '==',
                    'value' => 'templates/pages/akademik/kalender-akademik-page.php',
                ],
            ],
        ],
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (ALUR MAGANG CPT)
    ======================================== */
    acf_add_local_field_group([
        'key' => 'group_magang_alur_details',
        'title' => 'Detail Tahapan Alur Magang',
        'fields' => [
            [
                'key' => 'field_magang_jenis',
                'label' => 'Jenis Magang',
                'name' => 'jenis_magang',
                'type' => 'select',
                'choices' => [
                    'both' => 'Keduanya (Kolektif & Mandiri)',
                    'kolektif' => 'Magang Kolektif (Mitra)',
                    'mandiri' => 'Magang Mandiri',
                ],
                'default_value' => 'both',
                'instructions' => 'Pilih apakah tahapan alur ini berlaku untuk Magang Kolektif, Mandiri, atau Keduanya.',
            ],
            [
                'key' => 'field_magang_step',
                'label' => 'Label Tahap',
                'name' => 'step',
                'type' => 'text',
                'instructions' => 'Contoh: Tahap 01, Langkah 1',
            ],
            [
                'key' => 'field_magang_button_text',
                'label' => 'Teks Tombol Aksi',
                'name' => 'button_text',
                'type' => 'text',
                'instructions' => 'Contoh: Portal JTI, Upload Surat (kosongkan jika tidak ada tombol)',
            ],
            [
                'key' => 'field_magang_button_url',
                'label' => 'URL / Link Tombol',
                'name' => 'button_url',
                'type' => 'url',
                'instructions' => 'Contoh: https://jti.polinema.ac.id/portal',
            ],
            [
                'key' => 'field_magang_icon',
                'label' => 'Ikon Phosphor',
                'name' => 'icon',
                'type' => 'text',
                'instructions' => 'Class ikon Phosphor, contoh: ph-sign-in, ph-user-gear, ph-upload-simple',
            ],
        ],
        'location' => [
            [
                [
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'magang_alur',
                ],
            ],
        ],
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (ATURAN AKADEMIK CPT)
    ======================================== */

    // Field Group untuk CPT Aturan Akademik (Setiap Sub-Judul)
    acf_add_local_field_group([
        'key'    => 'group_cpt_aturan_akademik',
        'title'  => 'Detail Aturan Akademik',
        'fields' => [
            [
                'key'          => 'field_aa_cpt_description',
                'label'        => 'Deskripsi Konten',
                'name'         => 'aa_description',
                'type'         => 'wysiwyg',
                'instructions' => 'Isi konten sub-judul ini. Mendukung paragraf biasa, bullet list (•), dan penomoran (1. 2. 3.).',
                'required'     => 0,
                'media_upload' => 0,
                'toolbar'      => 'full',
                'tabs'         => 'visual',
            ],
            [
                'key'           => 'field_aa_cpt_icon',
                'label'         => 'Icon (Phosphor Icon)',
                'name'          => 'aa_icon',
                'type'          => 'text',
                'instructions'  => 'Nama icon Phosphor tanpa "ph-". Contoh: chalkboard-teacher, calendar-blank, user-minus, clipboard-text, star, graduation-cap, exam, identification-card, trophy, book-open',
                'default_value' => 'book-open',
            ],
            [
                'key'           => 'field_aa_cpt_image',
                'label'         => 'Gambar Pendukung (Opsional)',
                'name'          => 'aa_image',
                'type'          => 'image',
                'instructions'  => 'Upload foto atau diagram pendukung jika ada',
                'return_format' => 'array',
                'preview_size'  => 'medium',
                'library'       => 'all',
            ],
            [
                'key'          => 'field_aa_cpt_caption',
                'label'        => 'Caption Gambar (Opsional)',
                'name'         => 'aa_caption',
                'type'         => 'text',
                'instructions' => 'Keterangan di bawah foto',
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'post_type',
                    'operator' => '==',
                    'value'    => 'aturan_akademik',
                ],
            ],
        ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'active'                => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (COMPANY PARTNER CPT)
    ======================================== */

    // ACF Fields for Company Partner CPT
    acf_add_local_field_group([
        'key' => 'group_company_partner_details',
        'title' => 'Detail Perusahaan Magang',
        'fields' => [
            [
                'key' => 'field_company_category',
                'label' => 'Bidang Industri / Kategori',
                'name' => 'category',
                'type' => 'text',
                'instructions' => 'Contoh: Telecommunication & IT, Banking, E-Commerce, Software House',
            ],
            [
                'key' => 'field_company_location',
                'label' => 'Lokasi / Kota',
                'name' => 'location',
                'type' => 'text',
                'instructions' => 'Contoh: Malang, Surabaya, Jakarta, Remote',
            ],
        ],
        'location' => [
            [
                [
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'company_partner',
                ],
            ],
        ],
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (DEDICATION CPT)
    ======================================== */

    acf_add_local_field_group([
        'key' => 'group_dedication_details',
        'title' => 'Dedication Details',
        'fields' => [
            [
                'key' => 'field_dedication_year',
                'label' => 'Execution Year',
                'name' => 'year',
                'type' => 'text',
                'instructions' => 'Year of dedication project execution (e.g. 2025, 2024)',
                'required' => 1,
                'default_value' => date('Y'),
            ],
            [
                'key' => 'field_dedication_leader',
                'label' => 'Team Leader (Ketua)',
                'name' => 'leader',
                'type' => 'post_object',
                'instructions' => 'Select the team leader from Lecturers (Tenaga Pengajar)',
                'required' => 1,
                'post_type' => ['lecturer', 'dosen'],
                'return_format' => 'id',
                'ui' => 1,
            ],
            [
                'key' => 'field_dedication_members',
                'label' => 'Team Members (Anggota)',
                'name' => 'members',
                'type' => 'post_object',
                'instructions' => 'Select 4 to 7 team members from Lecturers (Tenaga Pengajar)',
                'required' => 1,
                'post_type' => ['lecturer', 'dosen'],
                'multiple' => 1,
                'return_format' => 'id',
                'ui' => 1,
            ],
            [
                'key' => 'field_dedication_study_program',
                'label' => 'Study Program',
                'name' => 'study_program',
                'type' => 'post_object',
                'instructions' => 'Select the associated study program',
                'required' => 1,
                'post_type' => ['study_program', 'prodi', 'program_studi'],
                'return_format' => 'id',
                'ui' => 1,
            ],
            [
                'key' => 'field_dedication_scheme',
                'label' => 'Dedication Scheme (Skema)',
                'name' => 'scheme',
                'type' => 'post_object',
                'instructions' => 'Select the scheme from Dedication Schemes',
                'required' => 1,
                'post_type' => ['dedication_scheme'],
                'return_format' => 'id',
                'ui' => 1,
            ],
        ],
        'location' => [
            [
                [
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'dedication',
                ],
            ],
        ],
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (SARANA DAN PRASARANA PAGE)
    ======================================== */

    acf_add_local_field_group([
        'key'   => 'group_sarana_page',
        'title' => 'Sarana dan Prasarana - Header',
        'fields' => [
            [
                'key'           => 'field_sarana_intro_title',
                'label'         => 'Judul Header Halaman',
                'name'          => 'sarana_intro_title',
                'type'          => 'text',
                'instructions'  => 'Judul utama yang tampil di header halaman (kotak biru).',
                'default_value' => 'Sarana dan Prasarana',
            ],
            [
                'key'           => 'field_sarana_intro_desc',
                'label'         => 'Deskripsi Singkat Header',
                'name'          => 'sarana_intro_desc',
                'type'          => 'text',
                'instructions'  => 'Teks pendek di bawah judul header (opsional).',
                'default_value' => '',
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'page_template',
                    'operator' => '==',
                    'value'    => 'templates/pages/sarana-prasarana-page.php',
                ],
            ],
        ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'active'                => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (FASILITAS CPT)
    ======================================== */

    acf_add_local_field_group([
        'key'   => 'group_fasilitas_cpt',
        'title' => 'Detail Fasilitas',
        'fields' => [
            [
                'key'          => 'field_fasilitas_description',
                'label'        => 'Deskripsi Fasilitas',
                'name'         => 'fasilitas_description',
                'type'         => 'wysiwyg',
                'instructions' => 'Deskripsi lengkap mengenai fasilitas ini.',
                'toolbar'      => 'basic',
                'media_upload' => 0,
                'tabs'         => 'all',
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'post_type',
                    'operator' => '==',
                    'value'    => 'fasilitas',
                ],
            ],
        ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'active'                => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (KATEGORI FASILITAS TAXONOMY)
    ======================================== */

    acf_add_local_field_group([
        'key'   => 'group_kategori_fasilitas_taxonomy',
        'title' => 'Pengaturan Kategori Fasilitas',
        'fields' => [
            [
                'key'           => 'field_kategori_icon',
                'label'         => 'Icon Tab (Phosphor Class)',
                'name'          => 'kategori_icon',
                'type'          => 'text',
                'instructions'  => 'Nama class icon Phosphor untuk tombol tab kategori ini (contoh: ph-chalkboard-teacher, ph-users-three, ph-buildings, ph-monitor, ph-wheelchair). Lihat: phosphoricons.com',
                'default_value' => 'ph-folder',
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'taxonomy',
                    'operator' => '==',
                    'value'    => 'kategori_fasilitas',
                ],
            ],
        ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'active'                => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (KERJASAMA PAGE)
    ======================================== */

    acf_add_local_field_group([
        'key'   => 'group_cooperation_page',
        'title' => 'Manajemen Konten Kerjasama',
        'fields' => [
            [
                'key'           => 'field_cooperation_title',
                'label'         => 'Judul Header Kerjasama',
                'name'          => 'cooperation_title',
                'type'          => 'text',
                'instructions'  => 'Judul section kerjasama. Kosongkan untuk menggunakan judul default.',
                'default_value' => 'Inisiasi Kerjasama - Jurusan Teknologi Informasi, Politeknik Negeri Malang',
            ],
            [
                'key'           => 'field_cooperation_description',
                'label'         => 'Konten Deskriptif',
                'name'          => 'cooperation_description',
                'type'          => 'wysiwyg',
                'instructions'  => 'Isi deskripsi / informasi lengkap mengenai kerjasama. Jika kosong, akan menggunakan teks default.',
                'media_upload'  => 1,
                'toolbar'       => 'full',
                'tabs'          => 'all',
            ],
            [
                'key'           => 'field_cooperation_image',
                'label'         => 'Gambar Banner / Ilustrasi Kerjasama (Opsional)',
                'name'          => 'cooperation_image',
                'type'          => 'image',
                'instructions'  => 'Upload gambar banner atau ilustrasi untuk halaman kerjasama.',
                'return_format' => 'url',
                'preview_size'  => 'medium',
                'library'       => 'all',
            ],
            [
                'key'           => 'field_cooperation_button_show',
                'label'         => 'Tampilkan Tombol Action / Redirect?',
                'name'          => 'cooperation_button_show',
                'type'          => 'true_false',
                'instructions'  => 'Aktifkan jika ingin mengarahkan pengunjung ke form/link luar (misal: Form Pengajuan Kerjasama).',
                'ui'            => 1,
                'default_value' => 0,
            ],
            [
                'key'           => 'field_cooperation_button_text',
                'label'         => 'Teks Tombol',
                'name'          => 'cooperation_button_text',
                'type'          => 'text',
                'instructions'  => 'Teks yang tampil di tombol (contoh: Ajukan Kerjasama / Hubungi Kami).',
                'default_value' => 'Ajukan Kerjasama',
                'conditional_logic' => [
                    [
                        [
                            'field'    => 'field_cooperation_button_show',
                            'operator' => '==',
                            'value'    => '1',
                        ],
                    ],
                ],
            ],
            [
                'key'           => 'field_cooperation_button_url',
                'label'         => 'Link Destination (URL)',
                'name'          => 'cooperation_button_url',
                'type'          => 'url',
                'instructions'  => 'Tujuan URL saat tombol diklik (contoh: https://forms.gle/... atau mailto:jti@polinema.ac.id).',
                'default_value' => '',
                'conditional_logic' => [
                    [
                        [
                            'field'    => 'field_cooperation_button_show',
                            'operator' => '==',
                            'value'    => '1',
                        ],
                    ],
                ],
            ],
            [
                'key'           => 'field_cooperation_button_target',
                'label'         => 'Buka Link di Tab Baru?',
                'name'          => 'cooperation_button_target',
                'type'          => 'select',
                'choices'       => [
                    '_blank' => 'Ya, buka di tab baru (_blank)',
                    '_self'  => 'Tidak, buka di tab yang sama (_self)',
                ],
                'default_value' => '_blank',
                'conditional_logic' => [
                    [
                        [
                            'field'    => 'field_cooperation_button_show',
                            'operator' => '==',
                            'value'    => '1',
                        ],
                    ],
                ],
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'page_template',
                    'operator' => '==',
                    'value'    => 'templates/pages/cooperation-page.php',
                ],
            ],
        ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'active'                => true,
    ]);

    /* ========================================
       REGISTER ACF FIELD GROUPS (MAGANG PAGE)
    ======================================== */

    acf_add_local_field_group([
        'key'   => 'group_magang_page_settings',
        'title' => 'Pengaturan Halaman Magang / PKL',
        'fields' => [
            [
                'key'           => 'field_magang_info_box_show',
                'label'         => 'Tampilkan Box Informasi Tambahan?',
                'name'          => 'magang_info_box_show',
                'type'          => 'true_false',
                'instructions'  => 'Aktifkan untuk menampilkan kotak informasi di bawah section alur magang.',
                'ui'            => 1,
                'default_value' => 1,
            ],
            [
                'key'           => 'field_magang_info_box_type',
                'label'         => 'Tipe / Gaya Box Informasi',
                'name'          => 'magang_info_box_type',
                'type'          => 'select',
                'choices'       => [
                    'info'    => 'Info (Biru)',
                    'warning' => 'Peringatan / Catatan (Kuning / Oranye)',
                    'success' => 'Petunjuk / Sukses (Hijau)',
                ],
                'default_value' => 'info',
                'conditional_logic' => [
                    [
                        [
                            'field'    => 'field_magang_info_box_show',
                            'operator' => '==',
                            'value'    => '1',
                        ],
                    ],
                ],
            ],
            [
                'key'           => 'field_magang_info_box_title',
                'label'         => 'Judul Box Informasi',
                'name'          => 'magang_info_box_title',
                'type'          => 'text',
                'default_value' => 'Informasi Penting Perbedaan Magang Kolektif & Magang Mandiri',
                'conditional_logic' => [
                    [
                        [
                            'field'    => 'field_magang_info_box_show',
                            'operator' => '==',
                            'value'    => '1',
                        ],
                    ],
                ],
            ],
            [
                'key'           => 'field_magang_info_box_icon',
                'label'         => 'Ikon Phosphor',
                'name'          => 'magang_info_box_icon',
                'type'          => 'text',
                'instructions'  => 'Contoh: ph-info, ph-lightbulb, ph-warning-circle, ph-check-circle',
                'default_value' => 'ph-info',
                'conditional_logic' => [
                    [
                        [
                            'field'    => 'field_magang_info_box_show',
                            'operator' => '==',
                            'value'    => '1',
                        ],
                    ],
                ],
            ],
            [
                'key'           => 'field_magang_info_box_content',
                'label'         => 'Isi / Konten Informasi',
                'name'          => 'magang_info_box_content',
                'type'          => 'wysiwyg',
                'instructions'  => 'Isi penjelasan tambahan mengenai magang kolektif dan mandiri.',
                'media_upload'  => 0,
                'toolbar'       => 'basic',
                'default_value' => '<p><strong>Magang Kolektif:</strong> Dikelola secara terpusat oleh Jurusan TI bekerjasama dengan Perusahaan Mitra resmi. Mahasiswa memilih dan mendaftar lowongan yang telah disediakan di portal.</p><p><strong>Magang Mandiri:</strong> Mahasiswa mengajukan calon perusahaan/instansi secara mandiri di luar daftar mitra resmi, dengan verifikasi persetujuan kelayakan dari tim magang jurusan.</p>',
                'conditional_logic' => [
                    [
                        [
                            'field'    => 'field_magang_info_box_show',
                            'operator' => '==',
                            'value'    => '1',
                        ],
                    ],
                ],
            ],
        ],
        'location' => [
            [
                [
                    'param'    => 'page_template',
                    'operator' => '==',
                    'value'    => 'templates/pages/magang-page.php',
                ],
            ],
        ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
        'active'                => true,
    ]);

});

/* ========================================
   CUSTOM ACF POST OBJECT QUERY FILTERS
   ======================================== */
