<?php
/**
 * Register Custom Post Types for the theme
 *
 * @package WebJTI_Theme
 */

function webjti_register_theme_post_types() {

    // Register Ormawa Custom Post Type
    $labels = [
        'name'               => _x('Student Organizations', 'post type general name', 'webjti'),
        'singular_name'      => _x('Student Organization', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Student Organizations', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Student Organization', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Add New', 'ormawa', 'webjti'),
        'add_new_item'       => __('Add New Student Organization', 'webjti'),
        'new_item'           => __('New Student Organization', 'webjti'),
        'edit_item'          => __('Edit Student Organization', 'webjti'),
        'view_item'          => __('View Student Organization', 'webjti'),
        'all_items'          => __('All Student Organizations', 'webjti'),
        'search_items'       => __('Search Student Organizations', 'webjti'),
        'parent_item_colon'  => __('Parent Student Organization:', 'webjti'),
        'not_found'          => __('No student organizations found.', 'webjti'),
        'not_found_in_trash' => __('No student organizations found in Trash.', 'webjti')
    ];

    $args = [
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => ['slug' => 'student-affairs/organisasi-kemahasiswaan', 'with_front' => false],
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-groups',
        'supports'           => ['title', 'editor', 'thumbnail', 'excerpt'],
        'show_in_rest'       => true,
    ];

    register_post_type('ormawa', $args);

    // Register Gallery Kegiatan
    $gallery_labels = [
        'name'               => _x('Gallery Kegiatan', 'post type general name', 'webjti'),
        'singular_name'      => _x('Gallery Kegiatan', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Gallery Kegiatan', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Gallery Kegiatan', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Add New Gallery', 'ormawa_gallery', 'webjti'),
        'add_new_item'       => __('Add New Activity Gallery', 'webjti'),
        'new_item'           => __('New Activity Gallery', 'webjti'),
        'edit_item'          => __('Edit Activity Gallery', 'webjti'),
        'view_item'          => __('View Activity Gallery', 'webjti'),
        'all_items'          => __('All Gallery Kegiatan', 'webjti'),
        'search_items'       => __('Search Gallery Kegiatan', 'webjti'),
        'parent_item_colon'  => __('Parent Gallery:', 'webjti'),
        'not_found'          => __('No galleries found.', 'webjti'),
        'not_found_in_trash' => __('No galleries found in Trash.', 'webjti')
    ];

    $gallery_args = [
        'labels'             => $gallery_labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => 'edit.php?post_type=ormawa',
        'query_var'          => true,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'supports'           => ['title'],
        'show_in_rest'       => true,
    ];

    register_post_type('ormawa_gallery', $gallery_args);

    // Register Academic Regulations
    $aturan_labels = [
        'name'               => _x('Academic Regulations', 'post type general name', 'webjti'),
        'singular_name'      => _x('Academic Regulation', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Academic Regulations', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Academic Regulation', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Add New Sub-Judul', 'aturan_akademik', 'webjti'),
        'add_new_item'       => __('Add New Academic Regulation', 'webjti'),
        'new_item'           => __('New Academic Regulation', 'webjti'),
        'edit_item'          => __('Edit Academic Regulation', 'webjti'),
        'view_item'          => __('View Academic Regulation', 'webjti'),
        'all_items'          => __('All Academic Regulations', 'webjti'),
        'search_items'       => __('Search Academic Regulations', 'webjti'),
        'not_found'          => __('No academic regulations found.', 'webjti'),
        'not_found_in_trash' => __('No academic regulations found in Trash.', 'webjti')
    ];

    $aturan_args = [
        'labels'             => $aturan_labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 21,
        'menu_icon'          => 'dashicons-book-alt',
        'supports'           => ['title', 'page-attributes'],
        'show_in_rest'       => false,
    ];

    register_post_type('aturan_akademik', $aturan_args);

    // Register Alur Magang
    $alur_labels = [
        'name'               => _x('Alur Magang', 'post type general name', 'webjti'),
        'singular_name'      => _x('Alur Magang', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Alur Magang', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Alur Magang', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Tambah Baru', 'magang_alur', 'webjti'),
        'add_new_item'       => __('Tambah Tahapan Alur Magang', 'webjti'),
        'new_item'           => __('Alur Magang Baru', 'webjti'),
        'edit_item'          => __('Edit Alur Magang', 'webjti'),
        'view_item'          => __('Lihat Alur Magang', 'webjti'),
        'all_items'          => __('Semua Alur Magang', 'webjti'),
        'search_items'       => __('Cari Alur Magang', 'webjti'),
        'not_found'          => __('Tidak ada data alur magang.', 'webjti'),
        'not_found_in_trash' => __('Tidak ada data alur magang di Sampah.', 'webjti')
    ];

    $alur_args = [
        'labels'             => $alur_labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 25,
        'menu_icon'          => 'dashicons-list-view',
        'supports'           => ['title', 'page-attributes'],
        'show_in_rest'       => false,
    ];

    register_post_type('magang_alur', $alur_args);

    // Register Company Partner
    $company_labels = [
        'name'               => _x('Perusahaan Magang', 'post type general name', 'webjti'),
        'singular_name'      => _x('Perusahaan Magang', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Perusahaan Magang', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Perusahaan Magang', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Tambah Perusahaan', 'company_partner', 'webjti'),
        'add_new_item'       => __('Tambah Perusahaan Magang Baru', 'webjti'),
        'new_item'           => __('Perusahaan Magang Baru', 'webjti'),
        'edit_item'          => __('Edit Perusahaan Magang', 'webjti'),
        'view_item'          => __('Lihat Perusahaan Magang', 'webjti'),
        'all_items'          => __('Semua Perusahaan Magang', 'webjti'),
        'search_items'       => __('Cari Perusahaan Magang', 'webjti'),
        'not_found'          => __('Tidak ada data perusahaan magang.', 'webjti'),
        'not_found_in_trash' => __('Tidak ada data perusahaan magang di Sampah.', 'webjti')
    ];

    $company_args = [
        'labels'             => $company_labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 26,
        'menu_icon'          => 'dashicons-building',
        'supports'           => ['title', 'page-attributes'],
        'show_in_rest'       => false,
    ];

    register_post_type('company_partner', $company_args);

    // Register Dedication (Community Service / Pengabdian) CPT
    $dedication_labels = [
        'name'               => _x('Dedications', 'post type general name', 'webjti'),
        'singular_name'      => _x('Dedication', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Dedication', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Dedication', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Add New', 'dedication', 'webjti'),
        'add_new_item'       => __('Add New Dedication', 'webjti'),
        'new_item'           => __('New Dedication', 'webjti'),
        'edit_item'          => __('Edit Dedication', 'webjti'),
        'view_item'          => __('View Dedication', 'webjti'),
        'all_items'          => __('All Dedications', 'webjti'),
        'search_items'       => __('Search Dedications', 'webjti'),
        'parent_item_colon'  => __('Parent Dedication:', 'webjti'),
        'not_found'          => __('No dedications found.', 'webjti'),
        'not_found_in_trash' => __('No dedications found in Trash.', 'webjti')
    ];

    $dedication_args = [
        'labels'             => $dedication_labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => ['slug' => 'pengabdian', 'with_front' => false],
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 27,
        'menu_icon'          => 'dashicons-heart',
        'supports'           => ['title', 'editor', 'page-attributes'],
        'show_in_rest'       => true,
    ];

    register_post_type('dedication', $dedication_args);

    // Register Dedication Scheme CPT (Submenu under Dedication)
    $scheme_labels = [
        'name'               => _x('Dedication Schemes', 'post type general name', 'webjti'),
        'singular_name'      => _x('Dedication Scheme', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Dedication Schemes', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Dedication Scheme', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Add New Scheme', 'dedication_scheme', 'webjti'),
        'add_new_item'       => __('Add New Dedication Scheme', 'webjti'),
        'new_item'           => __('New Dedication Scheme', 'webjti'),
        'edit_item'          => __('Edit Dedication Scheme', 'webjti'),
        'view_item'          => __('View Dedication Scheme', 'webjti'),
        'all_items'          => __('All Dedication Schemes', 'webjti'),
        'search_items'       => __('Search Dedication Schemes', 'webjti'),
        'not_found'          => __('No dedication schemes found.', 'webjti'),
        'not_found_in_trash' => __('No dedication schemes found in Trash.', 'webjti')
    ];

    $scheme_args = [
        'labels'             => $scheme_labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => 'edit.php?post_type=dedication',
        'query_var'          => true,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'supports'           => ['title'],
        'show_in_rest'       => true,
    ];

    register_post_type('dedication_scheme', $scheme_args);

    // Register Lecturer (Tenaga Pengajar) CPT
    $lecturer_labels = [
        'name'               => _x('Lecturers', 'post type general name', 'webjti'),
        'singular_name'      => _x('Lecturer', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Lecturers', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Lecturer', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Add New', 'lecturer', 'webjti'),
        'add_new_item'       => __('Add New Lecturer', 'webjti'),
        'new_item'           => __('New Lecturer', 'webjti'),
        'edit_item'          => __('Edit Lecturer', 'webjti'),
        'view_item'          => __('View Lecturer', 'webjti'),
        'all_items'          => __('All Lecturers', 'webjti'),
        'search_items'       => __('Search Lecturers', 'webjti'),
        'not_found'          => __('No lecturers found.', 'webjti'),
        'not_found_in_trash' => __('No lecturers found in Trash.', 'webjti')
    ];

    $lecturer_args = [
        'labels'             => $lecturer_labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => ['slug' => 'tenaga-pengajar', 'with_front' => false],
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 22,
        'menu_icon'          => 'dashicons-businessman',
        'supports'           => ['title', 'editor', 'thumbnail', 'excerpt'],
        'show_in_rest'       => true,
    ];

    register_post_type('lecturer', $lecturer_args);

    // Register Study Program CPT
    $sp_labels = [
        'name'               => _x('Study Programs', 'post type general name', 'webjti'),
        'singular_name'      => _x('Study Program', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Study Programs', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Study Program', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Add New', 'study_program', 'webjti'),
        'add_new_item'       => __('Add New Study Program', 'webjti'),
        'new_item'           => __('New Study Program', 'webjti'),
        'edit_item'          => __('Edit Study Program', 'webjti'),
        'view_item'          => __('View Study Program', 'webjti'),
        'all_items'          => __('All Study Programs', 'webjti'),
        'search_items'       => __('Search Study Programs', 'webjti'),
        'not_found'          => __('No study programs found.', 'webjti'),
        'not_found_in_trash' => __('No study programs found in Trash.', 'webjti')
    ];

    $sp_args = [
        'labels'             => $sp_labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => ['slug' => 'program-studi', 'with_front' => false],
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 23,
        'menu_icon'          => 'dashicons-welcome-learn-more',
        'supports'           => ['title', 'editor', 'thumbnail'],
        'show_in_rest'       => true,
    ];

    register_post_type('study_program', $sp_args);

    // ── Register Fasilitas CPT ─────────────────────────────────────
    $fasilitas_labels = [
        'name'               => _x('Fasilitas', 'post type general name', 'webjti'),
        'singular_name'      => _x('Fasilitas', 'post type singular name', 'webjti'),
        'menu_name'          => _x('Fasilitas', 'admin menu', 'webjti'),
        'name_admin_bar'     => _x('Fasilitas', 'add new on admin bar', 'webjti'),
        'add_new'            => _x('Tambah Fasilitas', 'fasilitas', 'webjti'),
        'add_new_item'       => __('Tambah Fasilitas Baru', 'webjti'),
        'new_item'           => __('Fasilitas Baru', 'webjti'),
        'edit_item'          => __('Edit Fasilitas', 'webjti'),
        'view_item'          => __('Lihat Fasilitas', 'webjti'),
        'all_items'          => __('Semua Fasilitas', 'webjti'),
        'search_items'       => __('Cari Fasilitas', 'webjti'),
        'not_found'          => __('Tidak ada data fasilitas.', 'webjti'),
        'not_found_in_trash' => __('Tidak ada data fasilitas di Sampah.', 'webjti'),
    ];

    $fasilitas_args = [
        'labels'             => $fasilitas_labels,
        'public'             => true,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => false,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 28,
        'menu_icon'          => 'dashicons-building',
        'supports'           => ['title', 'thumbnail', 'excerpt', 'page-attributes'],
        'show_in_rest'       => true,
    ];

    register_post_type('fasilitas', $fasilitas_args);

    // ── Register Kategori Fasilitas Taxonomy ───────────────────────
    $kat_fasilitas_labels = [
        'name'              => _x('Kategori Fasilitas', 'taxonomy general name', 'webjti'),
        'singular_name'     => _x('Kategori Fasilitas', 'taxonomy singular name', 'webjti'),
        'search_items'      => __('Cari Kategori Fasilitas', 'webjti'),
        'all_items'         => __('Semua Kategori', 'webjti'),
        'edit_item'         => __('Edit Kategori', 'webjti'),
        'update_item'       => __('Update Kategori', 'webjti'),
        'add_new_item'      => __('Tambah Kategori Baru', 'webjti'),
        'new_item_name'     => __('Nama Kategori Baru', 'webjti'),
        'menu_name'         => __('Kategori Fasilitas', 'webjti'),
        'back_to_items'     => __('← Kembali ke Kategori', 'webjti'),
    ];

    register_taxonomy('kategori_fasilitas', ['fasilitas'], [
        'labels'            => $kat_fasilitas_labels,
        'hierarchical'      => true,
        'public'            => false,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => false,
        'show_in_rest'      => true,
    ]);

    // Temp flush to register the new CPT rewrite slugs
    flush_rewrite_rules(false);
}

add_action('init', 'webjti_register_theme_post_types');