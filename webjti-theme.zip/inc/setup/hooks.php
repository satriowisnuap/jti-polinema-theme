<?php

/* ========================================
   FEATURED NEWS — SINGLE SELECTION
   Otomatis menonaktifkan featured_news
   di post lain saat satu post disimpan
   dengan featured_news = 1 (true)
======================================== */

add_action('acf/save_post', function($post_id) {

  // Hanya berlaku untuk post type 'information'
  if (get_post_type($post_id) !== 'information') {
    return;
  }

  // Cek apakah post ini di-set sebagai featured
  $is_featured = get_field('featured_news', $post_id);

  if (!$is_featured) {
    return;
  }

  // Cari semua post information lain yang juga featured
  $others = new WP_Query([
    'post_type'      => 'information',
    'posts_per_page' => -1,
    'post_status'    => 'any',
    'post__not_in'   => [$post_id],
    'meta_query'     => [
      [
        'key'   => 'featured_news',
        'value' => '1',
      ],
    ],
  ]);

  if ($others->have_posts()) {
    while ($others->have_posts()) {
      $others->the_post();
      // Nonaktifkan featured_news di post lain
      update_field('featured_news', false, get_the_ID());
    }
    wp_reset_postdata();
  }

}, 20);

/* ========================================
   DEFAULT INFO INTERCEPTOR & SMART SEARCH REDIRECT
   Mengalihkan pencarian dengan 1 hasil langsung ke halaman terkait,
   serta mengadopsi rute fallback simulasi kustom.
======================================== */

add_action('template_redirect', function() {

  // Redirect child lecturer CPTs (education, certification, course) to parent lecturer
  if (is_singular(['lecturer_education', 'lecturer_certification', 'lecturer_course', 'pendidikan_dosen', 'sertifikasi_dosen', 'matkul_dosen', 'lecturer_certificati'])) {
    $lecturer = get_field('lecturer', get_the_ID());
    $lecturer_id = null;
    if (is_array($lecturer)) {
      $lecturer_id = !empty($lecturer[0]) ? (is_object($lecturer[0]) ? $lecturer[0]->ID : $lecturer[0]) : null;
    } elseif (is_object($lecturer)) {
      $lecturer_id = $lecturer->ID;
    } else {
      $lecturer_id = $lecturer;
    }

    if ($lecturer_id && get_post_status($lecturer_id) === 'publish') {
      wp_safe_redirect(get_permalink($lecturer_id));
      exit;
    } else {
      wp_safe_redirect(home_url('/lecturer'));
      exit;
    }
  }

  // Smart Search Redirect
  if ( is_search() ) {
    global $wp_query;
    if ( isset( $wp_query->posts ) && count( $wp_query->posts ) === 1 ) {
      $single_post = $wp_query->posts[0];
      wp_safe_redirect( get_permalink( $single_post->ID ) );
      exit;
    }
  }

  if (isset($_GET['default_info']) && !empty($_GET['default_info'])) {
    include get_template_directory() . '/templates/singles/single-information.php';
    exit;
  }

  if (isset($_GET['default_lecturer']) && !empty($_GET['default_lecturer'])) {
    include get_template_directory() . '/templates/singles/single-lecturer.php';
    exit;
  }

  if (isset($_GET['default_achievement']) && !empty($_GET['default_achievement'])) {
    include get_template_directory() . '/templates/singles/single-achievement.php';
    exit;
  }

  // Automatic Page / Fallback Routing for Akademik Pages
  $request_path = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
  $akademik_routes = [
    'd2-piranti-lunak'                => '/templates/pages/akademik/d2-piranti-lunak-page.php',
    'd3-mi-kediri'                    => '/templates/pages/akademik/d3-mi-kediri-page.php',
    'd3-mi-lumajang'                  => '/templates/pages/akademik/d3-mi-lumajang-page.php',
    'd4-teknik-informatika'           => '/templates/pages/akademik/d4-teknik-informatika-page.php',
    'd4-sistem-informasi-bisnis'      => '/templates/pages/akademik/d4-sistem-informasi-bisnis-page.php',
    's2-rekayasa-teknologi-informasi' => '/templates/pages/akademik/s2-rekayasa-teknologi-informasi-page.php',
    'kelas-internasional'             => '/templates/pages/akademik/kelas-internasional-page.php',
    'double-degree'                   => '/templates/pages/akademik/double-degree-page.php',
    'alih-jenjang'                    => '/templates/pages/akademik/alih-jenjang-page.php',
    'rpl'                             => '/templates/pages/akademik/rpl-page.php',
    'aturan-akademik'                 => '/templates/pages/akademik/aturan-akademik-page.php',
    'kalender-akademik'               => '/templates/pages/akademik/kalender-akademik-page.php',
    'student-affairs/magang'          => '/templates/pages/magang-page.php',
    'student-affairs/tata-tertib'     => '/templates/pages/tata-tertib-page.php',
    'praktik-kerja-lapangan-magang'   => '/templates/pages/magang-page.php',
    'pkl-magang'                      => '/templates/pages/magang-page.php',
    'pkl'                             => '/templates/pages/magang-page.php',
    'magang'                          => '/templates/pages/magang-page.php',
    'tata-tertib'                     => '/templates/pages/tata-tertib-page.php',
    'jurnal'                          => '/templates/pages/jurnal-page.php',
    'research/jurnal'                 => '/templates/pages/jurnal-page.php',
    'penelitian/jurnal'               => '/templates/pages/jurnal-page.php',
  ];

  if (isset($akademik_routes[$request_path])) {
    $template_file = get_template_directory() . $akademik_routes[$request_path];
    if (file_exists($template_file)) {
      status_header(200);
      include $template_file;
      exit;
    }
  }

});

/* ========================================
   INCLUDE CUSTOM POST TYPES IN SEARCH QUERY
   Memastikan kueri pencarian utama menggeledah data CPT kustom
======================================== */
add_action( 'pre_get_posts', function( $query ) {
  if ( $query->is_main_query() && $query->is_search() && ! is_admin() ) {
    // Only search in these specific post types
    $query->set( 'post_type', [ 'post', 'page', 'information', 'lecturer', 'staff', 'achievement', 'ormawa' ] );
  }
});

/* ========================================
   AJAX FILTER INFORMASI
======================================== */

add_action('wp_ajax_jti_filter_informasi', 'jti_ajax_filter_informasi');
add_action('wp_ajax_nopriv_jti_filter_informasi', 'jti_ajax_filter_informasi');

function jti_ajax_filter_informasi() {
  $type = isset($_POST['type']) ? sanitize_text_field($_POST['type']) : 'all';
  $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
  $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
  
  $posts_per_page = 6;
  $data = webjti_get_filtered_information($type, $search, $paged, $posts_per_page);
  
  ob_start();
  if (!empty($data['posts'])) {
    foreach ($data['posts'] as $item) {
      $info = [
        'url'          => $item['permalink'] ?? $item['url'] ?? '',
        'image'        => $item['image'] ?? '',
        'title'        => $item['title'] ?? '',
        'category'     => $item['category'] ?? $item['tag'] ?? '',
        'date'         => $item['date'] ?? '',
        'reading_time' => $item['reading_time'] ?? '',
        'excerpt'      => $item['excerpt'] ?? '',
      ];
      get_template_part(
        'template-parts/cards/information-card',
        null,
        [
          'info' => $info,
        ]
      );
    }
  } else {
    ?>
    <div class="information-no-results" style="grid-column: 1 / -1; text-align: center; padding: 60px 24px; width: 100%;">
      <i class="ph ph-newspaper" style="font-size: 64px; color: var(--neutral-04); margin-bottom: 16px; display: block; margin-left: auto; margin-right: auto;"></i>
      <h3 style="color: var(--neutral-09); margin-bottom: 8px; font-weight: 500; font-size: 20px;">Tidak Ada Informasi</h3>
      <p style="color: var(--neutral-06); font-size: 16px;">Maaf, tidak ada berita, pengumuman, atau agenda yang sesuai dengan kriteria filter atau pencarian Anda.</p>
    </div>
    <?php
  }
  $content_html = ob_get_clean();
  
  $pagination_html = '';
  if ($data['max_pages'] > 1) {
    $pagination_links = paginate_links([
      'total'     => $data['max_pages'],
      'current'   => $paged,
      'prev_next' => true,
      'prev_text' => '<i class="ph ph-arrow-left"></i> Sebelumnya',
      'next_text' => 'Selanjutnya <i class="ph ph-arrow-right"></i>',
      'type'      => 'plain',
    ]);
    if ($pagination_links) {
      $pagination_html = '<div class="pagination-container">' . $pagination_links . '</div>';
    }
  }
  
  wp_send_json_success([
    'content'    => $content_html,
    'pagination' => $pagination_html,
  ]);
}

/* ========================================
   SINGLE TEMPLATE ROUTING FILTER
   Automatically routes templates in templates/singles/
======================================== */
add_filter('single_template', function($template) {
  global $post;
  if ($post) {
    $post_type = $post->post_type;
    $custom_template = get_template_directory() . '/templates/singles/single-' . $post_type . '.php';
    if (file_exists($custom_template)) {
      return $custom_template;
    }
    // Fallback for prestasi CPT mapped to single-achievement.php
    if ($post_type === 'achievement') {
      $achievement_template = get_template_directory() . '/templates/singles/single-achievement.php';
      if (file_exists($achievement_template)) {
        return $achievement_template;
      }
    }
  }
  return $template;
});


