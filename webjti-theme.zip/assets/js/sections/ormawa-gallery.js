/* ========================================
   ORMAWA GALLERY — Auto-scroll + centering
   Handles:
   1. ≤4 items → centre track, no animation
   2. >4 items → duplicate items for infinite
      marquee, then start CSS animation
   3. Manual prev/next buttons pause & jump
======================================== */

(function () {
  'use strict';

  const CARD_WIDTH_PX  = 280;  // must match CSS --gallery-card-w
  const GAP_PX         = 20;
  const MAX_VISIBLE    = 4;
  // seconds per full original-set width (speed tuning)
  const PX_PER_SECOND  = 80;

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      document.querySelectorAll('.ormawa-gallery').forEach(initGallery);
    });
  } else {
    document.querySelectorAll('.ormawa-gallery').forEach(initGallery);
  }

  function initGallery (gallery) {

    const track   = gallery.querySelector('.ormawa-gallery__track, .slider-track');
    const container = gallery.querySelector('.slider-container');
    if (!track || !container) return;

    const items = Array.from(track.children);
    const total = items.length;
    if (!total) return;

    if (total <= MAX_VISIBLE) {
      // ── FEW ITEMS: centre, no animation ──────────────────────
      track.classList.add('is-centered');
      return;
    }

    // ── MANY ITEMS: infinite marquee ─────────────────────────
    // 1. Duplicate items so the loop is seamless
    items.forEach(item => {
      const clone = item.cloneNode(true);
      clone.setAttribute('aria-hidden', 'true');
      track.appendChild(clone);
    });

    // 2. Calculate the width of one full set
    const oneSetWidth = total * (CARD_WIDTH_PX + GAP_PX);
    const durationSec = Math.round(oneSetWidth / PX_PER_SECOND);

    // 3. Set CSS custom properties on the track
    track.style.setProperty('--gallery-scroll-dist', `-${oneSetWidth}px`);
    track.style.setProperty('--gallery-scroll-dur',  `${durationSec}s`);

    // 4. Start animation
    track.classList.add('is-auto-scrolling');

    // ── PAUSE / RESUME helpers ────────────────────────────────
    let isPaused   = false;
    let currentX   = 0;  // track manual offset for prev/next
    let rafId      = null;

    function pauseAnim () {
      isPaused = true;
      track.style.animationPlayState = 'paused';
    }

    function resumeAnim () {
      isPaused = false;
      track.style.animationPlayState = 'running';
    }

    // Pause on hover (CSS handles this too, but belt-and-suspenders)
    gallery.addEventListener('mouseenter', pauseAnim);
    gallery.addEventListener('mouseleave', () => {
      if (!isPaused) return; // guard double calls
      resumeAnim();
    });

    // ── PREV / NEXT buttons (optional, only rendered when >4) ─
    const prevBtn = gallery.querySelector('.slider-btn-prev');
    const nextBtn = gallery.querySelector('.slider-btn-next');

    if (prevBtn && nextBtn) {
      prevBtn.addEventListener('click', () => {
        // Just pause the animation so the user can read
        if (track.classList.contains('is-auto-scrolling')) {
          pauseAnim();
          // resume after 4 s of idle
          clearTimeout(prevBtn._timer);
          prevBtn._timer = setTimeout(resumeAnim, 4000);
        }
      });

      nextBtn.addEventListener('click', () => {
        if (track.classList.contains('is-auto-scrolling')) {
          pauseAnim();
          clearTimeout(nextBtn._timer);
          nextBtn._timer = setTimeout(resumeAnim, 4000);
        }
      });
    }

  }

})();
