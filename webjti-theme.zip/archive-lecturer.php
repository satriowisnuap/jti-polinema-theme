<?php
/**
 * Archive Template for Lecturer Custom Post Type
 *
 * @package WebJTI_Theme
 */

get_header();

?>

<main id="primary" class="site-main lecturer-page">

    <?php
    /*
    ==================================================
    PAGE HEADER
    ==================================================
    */
    get_template_part(
        'template-parts/components/page-header'
    );
    ?>

    <div class="container">

        <div class="page-layout with-sidebar">

            <?php
            /*
            ==================================================
            SIDEBAR NAVIGATION
            ==================================================
            */
            get_template_part(
                'template-parts/components/sidebar/sidebar'
            );
            ?>

            <div class="page-content lecturer-page-content">

                <?php
                /*
                ==================================================
                LECTURER GRID SECTION
                ==================================================
                */
                get_template_part(
                    'template-parts/sections/about us/lecturer/lecturer-section'
                );
                ?>

            </div><!-- .page-content -->

        </div><!-- .page-layout -->

    </div><!-- .container -->

</main><!-- #primary -->

<?php

get_footer();
